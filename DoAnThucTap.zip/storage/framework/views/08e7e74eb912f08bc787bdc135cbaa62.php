<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\DO_AN_CHUYEN_NGANH\DoAnThucTap\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>